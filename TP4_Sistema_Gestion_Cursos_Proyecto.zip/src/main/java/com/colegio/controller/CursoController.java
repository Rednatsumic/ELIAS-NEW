package com.colegio.controller;

import com.colegio.model.Curso;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/cursos")
public class CursoController {
    private final List<Curso> cursos = new ArrayList<>();

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'DOCENTE', 'ESTUDIANTE')")
    public List<Curso> listarCursos() {
        return cursos;
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public Curso agregarCurso(@RequestBody Curso curso) {
        cursos.add(curso);
        return curso;
    }
}
