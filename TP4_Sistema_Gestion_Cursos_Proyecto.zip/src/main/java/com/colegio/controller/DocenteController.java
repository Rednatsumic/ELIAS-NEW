package com.colegio.controller;

import com.colegio.model.Docente;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/docentes")
public class DocenteController {
    private final List<Docente> docentes = new ArrayList<>();

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'DOCENTE')")
    public List<Docente> listarDocentes() {
        return docentes;
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public Docente agregarDocente(@RequestBody Docente docente) {
        docentes.add(docente);
        return docente;
    }
}
