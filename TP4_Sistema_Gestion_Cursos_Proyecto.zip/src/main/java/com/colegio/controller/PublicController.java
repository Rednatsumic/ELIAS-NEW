package com.colegio.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PublicController {
    @GetMapping("/public")
    public String bienvenida() {
        return "Bienvenido al sistema de gestión de cursos del colegio";
    }
}
