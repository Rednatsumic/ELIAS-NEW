
document.getElementById("registerForm").addEventListener("submit", function (e) {
  e.preventDefault();
  const username = document.getElementById("username").value.toLowerCase();
  const password = document.getElementById("password").value;
  const errorMsg = document.getElementById("errorMsg");

  const badWords = ["mierda", "puta", "cagar", "idiota", "tonto"];
  if (badWords.some(word => username.includes(word))) {
    errorMsg.textContent = "El nombre de usuario contiene palabras inapropiadas.";
    return;
  }

  if (password.length < 6) {
    errorMsg.textContent = "La contraseña debe tener al menos 6 caracteres.";
    return;
  }

  errorMsg.style.color = "green";
  errorMsg.textContent = "✅ Usuario registrado con éxito (simulado).";
});
