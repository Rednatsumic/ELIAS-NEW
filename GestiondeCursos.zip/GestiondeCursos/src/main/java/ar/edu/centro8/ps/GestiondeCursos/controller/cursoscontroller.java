package ar.edu.centro8.ps.GestiondeCursos.controller;

import ar.edu.centro8.ps.GestiondeCursos.model.curso;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/cursos")
public class cursoscontroller {
    private final List<curso> cursos = new ArrayList<>();

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'DOCENTE', 'ESTUDIANTE')")
    public List<curso> listarCursos() {
        // Obtener el usuario autenticado
        String usuarioAutenticado = SecurityContextHolder.getContext().getAuthentication().getName();

        // Si el usuario es un docente, filtrar por los cursos que él dicta
        return cursos.stream()
                .filter(curso -> "ADMIN".equals(usuarioAutenticado) || curso.getDocenteId().equals(usuarioAutenticado))
                .collect(Collectors.toList());
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public curso agregarCurso(@RequestBody curso curso) {
        cursos.add(curso);
        return curso;
    }
}