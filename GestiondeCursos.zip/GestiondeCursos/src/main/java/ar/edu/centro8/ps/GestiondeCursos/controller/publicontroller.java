package ar.edu.centro8.ps.GestiondeCursos.controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController 
public class publicontroller {
    @GetMapping("/public")
    public String bienvenida() {
        return "Bienvenido al sistema de gestión de cursos del colegio";
    }
}
