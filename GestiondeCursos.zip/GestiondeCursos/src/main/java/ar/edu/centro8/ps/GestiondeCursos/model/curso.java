package ar.edu.centro8.ps.GestiondeCursos.model;

public class curso {
    private String nombre;
    private String docenteId; // El ID del docente que dicta el curso

    // Getters y setters
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getDocenteId() { return docenteId; }
    public void setDocenteId(String docenteId) { this.docenteId = docenteId; }
}