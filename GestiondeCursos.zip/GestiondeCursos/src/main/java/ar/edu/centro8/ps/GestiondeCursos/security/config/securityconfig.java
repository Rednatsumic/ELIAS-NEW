package ar.edu.centro8.ps.GestiondeCursos.security.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableMethodSecurity
public class securityconfig {
    @Bean
public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
    return http
        .csrf(csrf -> csrf.disable())
        .authorizeHttpRequests(auth -> auth
            .requestMatchers("/public").permitAll()
            .anyRequest().authenticated()
        )
        .httpBasic(httpBasic -> {})  // forma nueva
        .build();
}
    @Bean
    public UserDetailsService userDetailsService(PasswordEncoder encoder) {
        final UserDetails admin = User.builder()
            .username("admin")
            .password(encoder.encode("admin123"))
            .roles("ADMIN")
            .build();

        UserDetails docente = User.builder()
            .username("docente")
            .password(encoder.encode("docente123"))
            .roles("DOCENTE")
            .build();

        UserDetails estudiante = User.builder()
            .username("estudiante")
            .password(encoder.encode("estudiante123"))
            .roles("ESTUDIANTE")
            .build();

        return new InMemoryUserDetailsManager(admin, docente, estudiante);
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
