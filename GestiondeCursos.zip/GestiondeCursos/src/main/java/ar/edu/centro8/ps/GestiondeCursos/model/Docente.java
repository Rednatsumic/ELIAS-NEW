package ar.edu.centro8.ps.GestiondeCursos.model;

public class Docente {
    private String nombre;

    public Docente() {
    }

    public Docente(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}