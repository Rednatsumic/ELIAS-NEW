package ar.edu.centro8.ps.GestiondeCursos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestiondeCursosApplicationTests {

	@Test
	void contextLoads() {
	}

}
